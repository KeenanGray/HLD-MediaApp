﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UI_Builder
{
    public class UIB_View : MonoBehaviour
    {

        //This script exists to 'Tag' objects as parts of app_pages

    }
}
