﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UAP_Video_SettingsMenu : MonoBehaviour
{
	public void OnCloseButtonPressed()
	{
		Destroy(gameObject);
	}
}
